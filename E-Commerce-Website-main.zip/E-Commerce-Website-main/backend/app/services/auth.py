from sqlalchemy.ext.asyncio import AsyncSession
from app.repositories.user import UserRepository
from app.schemas.user import UserRegister, UserLogin, TokenResponse, UserResponse
from app.core.security import verify_password, get_password_hash, create_access_token
from app.core.exceptions import ConflictError, UnauthorizedError
from app.core.logging import get_logger

logger = get_logger(__name__)


class AuthService:
    def __init__(self, db: AsyncSession):
        self.repo = UserRepository(db)

    async def register(self, data: UserRegister) -> TokenResponse:
        if await self.repo.exists_by_email(data.email):
            raise ConflictError("A user with this email already exists.")

        hashed_password = get_password_hash(data.password)
        user = await self.repo.create(
            email=data.email,
            first_name=data.first_name,
            last_name=data.last_name,
            hashed_password=hashed_password,
        )
        logger.info(f"New user registered: {user.email}")

        access_token = create_access_token(subject=str(user.id))
        return TokenResponse(
            access_token=access_token,
            user=UserResponse.model_validate(user),
        )

    async def login(self, data: UserLogin) -> TokenResponse:
        user = await self.repo.get_by_email(data.email)
        if not user or not verify_password(data.password, user.hashed_password):
            raise UnauthorizedError("Invalid email or password.")

        if not user.is_active:
            raise UnauthorizedError("Your account has been deactivated.")

        logger.info(f"User logged in: {user.email}")
        access_token = create_access_token(
            subject=str(user.id),
            extra_data={"is_owner": user.is_owner},
        )
        return TokenResponse(
            access_token=access_token,
            user=UserResponse.model_validate(user),
        )
