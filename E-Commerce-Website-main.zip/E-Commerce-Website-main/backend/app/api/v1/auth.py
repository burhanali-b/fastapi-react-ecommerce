from fastapi import APIRouter, Depends, status
from sqlalchemy.ext.asyncio import AsyncSession
from app.database.session import get_db
from app.schemas.user import UserRegister, UserLogin, TokenResponse
from app.schemas.base import success_response
from app.services.auth import AuthService

router = APIRouter(prefix="/auth", tags=["Authentication"])


@router.post("/register", status_code=status.HTTP_201_CREATED)
async def register(data: UserRegister, db: AsyncSession = Depends(get_db)):
    """Register a new customer account."""
    service = AuthService(db)
    result = await service.register(data)
    return success_response(
        data=result.model_dump(),
        message="Registration successful.",
    )


@router.post("/login")
async def login(data: UserLogin, db: AsyncSession = Depends(get_db)):
    """Login with email and password."""
    service = AuthService(db)
    result = await service.login(data)
    return success_response(
        data=result.model_dump(),
        message="Login successful.",
    )
