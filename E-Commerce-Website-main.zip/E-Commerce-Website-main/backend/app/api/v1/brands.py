import uuid
from fastapi import APIRouter, Depends, status
from sqlalchemy.ext.asyncio import AsyncSession
from app.database.session import get_db
from app.schemas.brand import BrandCreate, BrandUpdate
from app.schemas.base import success_response
from app.services.brand import BrandService
from app.dependencies.auth import get_current_owner
from app.models.user import User

router = APIRouter(prefix="/brands", tags=["Brands"])


@router.get("/")
async def list_brands(db: AsyncSession = Depends(get_db)):
    """List all brands (public)."""
    service = BrandService(db)
    result = await service.get_all()
    return success_response(data=[r.model_dump() for r in result], message="Brands retrieved.")


@router.get("/{brand_id}")
async def get_brand(brand_id: uuid.UUID, db: AsyncSession = Depends(get_db)):
    """Get a single brand by ID (public)."""
    service = BrandService(db)
    result = await service.get_by_id(brand_id)
    return success_response(data=result.model_dump(), message="Brand retrieved.")


@router.post("/", status_code=status.HTTP_201_CREATED)
async def create_brand(
    data: BrandCreate,
    db: AsyncSession = Depends(get_db),
    owner: User = Depends(get_current_owner),
):
    """Create a new brand (owner only)."""
    service = BrandService(db)
    result = await service.create(data)
    return success_response(data=result.model_dump(), message="Brand created.")


@router.put("/{brand_id}")
async def update_brand(
    brand_id: uuid.UUID,
    data: BrandUpdate,
    db: AsyncSession = Depends(get_db),
    owner: User = Depends(get_current_owner),
):
    """Update a brand (owner only)."""
    service = BrandService(db)
    result = await service.update(brand_id, data)
    return success_response(data=result.model_dump(), message="Brand updated.")


@router.delete("/{brand_id}", status_code=status.HTTP_200_OK)
async def delete_brand(
    brand_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    owner: User = Depends(get_current_owner),
):
    """Delete a brand (owner only)."""
    service = BrandService(db)
    await service.delete(brand_id)
    return success_response(message="Brand deleted.")
