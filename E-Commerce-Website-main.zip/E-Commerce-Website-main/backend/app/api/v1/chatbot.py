from typing import Literal

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy.ext.asyncio import AsyncSession
import httpx
from google import genai

from app.core.config import settings
from app.database.session import get_db
from app.dependencies.auth import get_current_user
from app.models.user import User
from app.repositories.product import ProductRepository
from app.schemas.base import success_response

router = APIRouter(prefix="/chatbot", tags=["Chatbot"])

class ChatHistoryItem(BaseModel):
    role: Literal['user', 'assistant']
    text: str

class ChatRequest(BaseModel):
    message: str
    history: list[ChatHistoryItem] = []

class ChatResponse(BaseModel):
    reply: str

def _is_placeholder_key(value: str | None) -> bool:
    return value is None or value.strip() == '' or value.startswith('YOUR_')


async def _call_openai_model(openai_api_key: str, message: str) -> str:
    async with httpx.AsyncClient(timeout=30.0) as client:
        response = await client.post(
            'https://api.openai.com/v1/chat/completions',
            headers={
                'Authorization': f'Bearer {openai_api_key}',
                'Content-Type': 'application/json',
            },
            json={
                'model': 'gpt-3.5-turbo',
                'messages': [
                    {'role': 'system', 'content': 'You are a helpful e-commerce assistant.'},
                    {'role': 'user', 'content': message},
                ],
                'temperature': 0.7,
                'max_tokens': 200,
            },
        )

    if response.status_code != 200:
        try:
            error_detail = response.json().get('error', {}).get('message') or response.text
        except ValueError:
            error_detail = response.text
        raise HTTPException(status_code=500, detail=f'OpenAI error: {error_detail}')

    result = response.json()
    return result['choices'][0]['message']['content'].strip()


@router.post("/query")
async def chatbot_query(
    data: ChatRequest,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    google_api_key = settings.GOOGLE_API_KEY
    openai_api_key = settings.OPENAI_API_KEY

    if google_api_key and not _is_placeholder_key(google_api_key):
        client = genai.Client(api_key=google_api_key)
        product_repo = ProductRepository(db)

        search_text = ' '.join(
            [item.text for item in data.history if item.role == 'user'] + [data.message]
        ).strip() or data.message

        # If possible, retrieve products relevant to the customer's current intent; otherwise use a general sample.
        products, total = await product_repo.get_all(page=1, page_size=5, search=search_text)
        if total == 0:
            products, _ = await product_repo.get_all(page=1, page_size=5)

        product_context = []
        for product in products:
            product_context.append(
                f"Name: {product.name}\nPrice: ${product.price}\nStock: {product.stock_quantity}\n"
                f"Category: {product.category.name if product.category else 'N/A'}\n"
                f"Brand: {product.brand.name if product.brand else 'N/A'}\n"
                f"Description: {product.description or 'No description.'}"
            )

        if product_context:
            context_text = (
                "Use the following product catalog context to answer customer questions. "
                "Answer only questions about this store, its products, pricing, availability, categories, brands, and shipping. "
                "Do not invent answers about other stores, unrelated topics, or external services. "
                "If the customer asks about anything outside this store's products or services, politely say that you can only provide information about this store and its catalogue.\n\n"
                "Product context:\n" + "\n---\n".join(product_context) + "\n\n"
            )
        else:
            context_text = (
                "You are a friendly e-commerce assistant for a chemical store. "
                "Answer only questions about this store, its products, pricing, availability, categories, brands, shipping, and order process. "
                "If the question is outside this store's scope, say you can only provide information about this store and direct the customer to the website or support.\n\n"
            )

        conversation_lines = []
        for item in data.history:
            conversation_lines.append(f"{item.role.capitalize()}: {item.text}")
        conversation_lines.append(f"User: {data.message}")

        augmented_prompt = (
            f"{context_text}"
            "You are an information-only assistant. Provide product details, availability, pricing, categories, brand information, stock, and shipping info for this store only. "
            "Do not answer questions about other stores, other product lines, unrelated subjects, or personal/medical/legal advice. "
            "If the user asks about anything outside this store or requests actions like ordering, checkout, or payment, politely explain that you can only provide information about the store and its products, and suggest they use the website to complete purchases.\n\n"
            "Use the conversation history to understand follow-up requests and keep answers focused on this store.\n\n"
            "Conversation so far:\n"
            f"{'\n'.join(conversation_lines)}\n\n"
            "Assistant:"
        )

        try:
            response = client.models.generate_content(
                model='gemini-3.1-flash-lite',
                contents=augmented_prompt,
            )
            reply = getattr(response, 'text', None) or getattr(response, 'content', None) or str(response)
            reply = reply.strip() if isinstance(reply, str) else ''
            if reply:
                return success_response(data={"reply": reply}, message="Chatbot response.")
        except Exception as exc:
            last_error = str(exc)
            if openai_api_key and not _is_placeholder_key(openai_api_key):
                openai_reply = await _call_openai_model(openai_api_key, data.message)
                return success_response(data={"reply": openai_reply}, message="Chatbot response.")
            raise HTTPException(
                status_code=500,
                detail=(
                    'Gemini RAG request failed. Make sure your Gemini API key is valid and the model is supported. '
                    f'{last_error}'
                ),
            )

    if openai_api_key and not _is_placeholder_key(openai_api_key):
        async with httpx.AsyncClient(timeout=30.0) as client:
            response = await client.post(
                'https://api.openai.com/v1/chat/completions',
                headers={
                    'Authorization': f'Bearer {openai_api_key}',
                    'Content-Type': 'application/json',
                },
                json={
                    'model': 'gpt-3.5-turbo',
                    'messages': [
                        {'role': 'system', 'content': 'You are a helpful e-commerce assistant.'},
                        {'role': 'user', 'content': data.message},
                    ],
                    'temperature': 0.7,
                    'max_tokens': 200,
                },
            )

        if response.status_code != 200:
            try:
                error_detail = response.json().get('error', {}).get('message') or response.text
            except ValueError:
                error_detail = response.text
            raise HTTPException(status_code=500, detail=f'OpenAI error: {error_detail}')

        result = response.json()
        reply = result['choices'][0]['message']['content'].strip()
        return success_response(data={"reply": reply}, message="Chatbot response.")

    raise HTTPException(status_code=500, detail='Chatbot API key is not configured. Set GOOGLE_API_KEY or OPENAI_API_KEY.')
