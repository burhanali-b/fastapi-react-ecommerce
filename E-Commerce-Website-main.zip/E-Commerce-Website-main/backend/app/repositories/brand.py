import uuid
from typing import Optional
from sqlalchemy import select, func
from sqlalchemy.ext.asyncio import AsyncSession
from app.models.brand import Brand
from app.utils.slug import generate_slug


class BrandRepository:
    def __init__(self, db: AsyncSession):
        self.db = db

    async def get_all(self) -> list[Brand]:
        result = await self.db.execute(select(Brand).order_by(Brand.name))
        return list(result.scalars().all())

    async def get_by_id(self, brand_id: uuid.UUID) -> Optional[Brand]:
        result = await self.db.execute(select(Brand).where(Brand.id == brand_id))
        return result.scalar_one_or_none()

    async def get_by_slug(self, slug: str) -> Optional[Brand]:
        result = await self.db.execute(select(Brand).where(Brand.slug == slug))
        return result.scalar_one_or_none()

    async def get_by_name(self, name: str) -> Optional[Brand]:
        result = await self.db.execute(
            select(Brand).where(func.lower(Brand.name) == name.lower())
        )
        return result.scalar_one_or_none()

    async def create(self, name: str, description: Optional[str] = None) -> Brand:
        slug = await self._unique_slug(name)
        brand = Brand(name=name, slug=slug, description=description)
        self.db.add(brand)
        await self.db.flush()
        await self.db.refresh(brand)
        return brand

    async def update(self, brand: Brand, **kwargs) -> Brand:
        if "name" in kwargs and kwargs["name"]:
            kwargs["slug"] = await self._unique_slug(kwargs["name"], exclude_id=brand.id)
        for key, value in kwargs.items():
            if hasattr(brand, key):
                setattr(brand, key, value)
        await self.db.flush()
        await self.db.refresh(brand)
        return brand

    async def delete(self, brand: Brand) -> None:
        await self.db.delete(brand)
        await self.db.flush()

    async def _unique_slug(self, name: str, exclude_id: Optional[uuid.UUID] = None) -> str:
        base_slug = generate_slug(name)
        slug = base_slug
        counter = 1
        while True:
            q = select(Brand.id).where(Brand.slug == slug)
            if exclude_id:
                q = q.where(Brand.id != exclude_id)
            result = await self.db.execute(q)
            if result.scalar_one_or_none() is None:
                return slug
            slug = f"{base_slug}-{counter}"
            counter += 1
